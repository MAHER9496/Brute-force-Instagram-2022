
# PROXY-LIST

A list of Free, Scrapped Public Proxies. UPDATED REGULARLY !!!  

Last Updated: `Friday 15-04-2022 18:27:55 UTC`  
Total Proxies: `5560`  

## DOWNLOAD

### For SOCKS5

```curl https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt -o socks5.txt```

### For SOCKS4

```curl https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks4.txt -o socks4.txt```

### For HTTP(S)

```curl https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt -o http.txt```

## NOTES

It is Only For Educational Purposes. Neither I Say Nor I Promote To Do Anything Illegal.

Please Give Credits, Stars, And Follow If You Use My SOCKS List.  

You can Also Use My Tool [SOCKER](https://github.com/TheSpeedX/socker) To check for working SOCKS PROXY.

## CONTACT

 For Any Queries:  
        Ping Me : [Telegram](http://t.me/the_space_bar)
